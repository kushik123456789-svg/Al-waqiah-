import { useParams, Link, useNavigate } from 'react-router';
import { Star, ShoppingCart, ArrowLeft, Check } from 'lucide-react';
import { products } from '../data/products';
import { useCart } from '../context/CartContext';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { useState } from 'react';

export default function ProductDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const [quantity, setQuantity] = useState(1);
  const [added, setAdded] = useState(false);

  const product = products.find(p => p.id === id);

  if (!product) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">Product Not Found</h2>
          <Link to="/">
            <Button>Back to Home</Button>
          </Link>
        </div>
      </div>
    );
  }

  const handleAddToCart = () => {
    for (let i = 0; i < quantity; i++) {
      addToCart(product);
    }
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  const discount = product.originalPrice
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* Back Button */}
        <Button
          variant="ghost"
          className="mb-6"
          onClick={() => navigate(-1)}
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Product Image */}
          <div className="relative">
            <img
              src={product.image}
              alt={product.name}
              className="w-full aspect-square object-cover rounded-lg shadow-lg"
            />
            {discount > 0 && (
              <Badge className="absolute top-4 right-4 bg-red-500 hover:bg-red-600 text-lg px-4 py-2">
                -{discount}%
              </Badge>
            )}
          </div>

          {/* Product Info */}
          <div>
            <div className="text-sm text-gray-500 mb-2">{product.brand}</div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              {product.name}
            </h1>
            <p className="text-lg text-gray-600 mb-4">{product.name_bn}</p>

            {/* Rating */}
            <div className="flex items-center space-x-2 mb-6">
              <div className="flex items-center space-x-1">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-5 h-5 ${
                      i < Math.floor(product.rating)
                        ? 'fill-yellow-400 text-yellow-400'
                        : 'text-gray-300'
                    }`}
                  />
                ))}
              </div>
              <span className="font-medium">{product.rating}</span>
              <span className="text-gray-500">({product.reviewCount} reviews)</span>
            </div>

            {/* Price */}
            <div className="mb-6">
              <div className="flex items-end space-x-3 mb-2">
                <span className="text-4xl font-bold text-pink-600">
                  ৳{product.price}
                </span>
                {product.originalPrice && (
                  <span className="text-2xl text-gray-400 line-through">
                    ৳{product.originalPrice}
                  </span>
                )}
              </div>
              {discount > 0 && (
                <p className="text-sm text-green-600 font-medium">
                  You save ৳{product.originalPrice! - product.price} ({discount}% off)
                </p>
              )}
            </div>

            {/* Description */}
            <div className="mb-6">
              <h3 className="font-bold mb-2">Description</h3>
              <p className="text-gray-600">{product.description}</p>
            </div>

            {/* Benefits */}
            <div className="mb-6">
              <h3 className="font-bold mb-2">Key Benefits</h3>
              <div className="flex flex-wrap gap-2">
                {product.benefits.map(benefit => (
                  <Badge
                    key={benefit}
                    variant="outline"
                    className="px-3 py-2 bg-pink-50 text-pink-700 border-pink-200"
                  >
                    <Check className="w-4 h-4 mr-1" />
                    {benefit}
                  </Badge>
                ))}
              </div>
            </div>

            {/* Skin Type */}
            <div className="mb-6">
              <h3 className="font-bold mb-2">Suitable for</h3>
              <div className="flex flex-wrap gap-2">
                {product.skinType.map(type => (
                  <Badge key={type} variant="secondary" className="capitalize">
                    {type} skin
                  </Badge>
                ))}
              </div>
            </div>

            {/* Stock Status */}
            <div className="mb-6">
              {product.inStock ? (
                <Badge className="bg-green-100 text-green-800 hover:bg-green-100">
                  In Stock
                </Badge>
              ) : (
                <Badge variant="destructive">Out of Stock</Badge>
              )}
            </div>

            {/* Quantity and Add to Cart */}
            <div className="flex items-center space-x-4 mb-6">
              <div className="flex items-center border rounded-lg">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="px-4 py-2 hover:bg-gray-100"
                >
                  -
                </button>
                <span className="px-6 py-2 border-x">{quantity}</span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="px-4 py-2 hover:bg-gray-100"
                >
                  +
                </button>
              </div>
              <Button
                onClick={handleAddToCart}
                disabled={!product.inStock}
                className="flex-1 bg-pink-600 hover:bg-pink-700 h-12"
              >
                {added ? (
                  <>
                    <Check className="w-5 h-5 mr-2" />
                    Added to Cart!
                  </>
                ) : (
                  <>
                    <ShoppingCart className="w-5 h-5 mr-2" />
                    Add to Cart
                  </>
                )}
              </Button>
            </div>

            {/* Additional Info */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 text-sm">
              <p className="font-medium text-blue-900 mb-1">Free Delivery</p>
              <p className="text-blue-700">
                Free delivery in Dhaka for orders over ৳1500
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
