import { Link } from 'react-router';
import { categories, products } from '../data/products';
import { ArrowRight } from 'lucide-react';

export default function Categories() {
  const getCategoryProductCount = (categoryId: string) => {
    if (categoryId === 'all') return products.length;
    return products.filter(p => p.category === categoryId).length;
  };

  const getCategoryImage = (categoryId: string) => {
    const product = products.find(p => p.category === categoryId);
    return product?.image || products[0].image;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Shop by Category</h1>
          <p className="text-gray-600">ক্যাটাগরি অনুযায়ী কেনাকাটা করুন</p>
        </div>

        {/* Categories Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {categories
            .filter(cat => cat.id !== 'all')
            .map(category => (
              <Link
                key={category.id}
                to={`/?category=${category.id}`}
                className="group block"
              >
                <div className="bg-white rounded-lg shadow overflow-hidden hover:shadow-lg transition-shadow">
                  {/* Category Image */}
                  <div className="relative h-48 overflow-hidden bg-gradient-to-br from-pink-100 to-purple-100">
                    <img
                      src={getCategoryImage(category.id)}
                      alt={category.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                    <div className="absolute bottom-4 left-4 text-white">
                      <h3 className="text-xl font-bold">{category.name}</h3>
                      <p className="text-sm opacity-90">{category.name_bn}</p>
                    </div>
                  </div>

                  {/* Category Info */}
                  <div className="p-4 flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600">
                        {getCategoryProductCount(category.id)} products
                      </p>
                    </div>
                    <ArrowRight className="w-5 h-5 text-pink-600 group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>
              </Link>
            ))}
        </div>

        {/* Featured Banner */}
        <div className="mt-12 bg-gradient-to-r from-pink-500 to-purple-600 rounded-lg p-8 text-white">
          <h2 className="text-2xl font-bold mb-2">
            Can't decide? Try our bestsellers!
          </h2>
          <p className="mb-4 opacity-90">
            সিদ্ধান্ত নিতে পারছেন না? আমাদের বেস্টসেলার পণ্য দেখুন!
          </p>
          <Link to="/">
            <button className="bg-white text-pink-600 px-6 py-2 rounded-lg font-medium hover:bg-gray-100 transition-colors">
              View All Products
            </button>
          </Link>
        </div>
      </div>
    </div>
  );
}
