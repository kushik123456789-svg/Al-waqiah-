import { Link } from 'react-router';
import { ShoppingBag, ArrowRight } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { CartItem } from '../components/CartItem';
import { Button } from '../components/ui/button';
import { Separator } from '../components/ui/separator';

export default function Cart() {
  const { items, getTotalPrice, clearCart } = useCart();
  const totalPrice = getTotalPrice();
  const deliveryFee = totalPrice >= 1500 ? 0 : 60;
  const finalTotal = totalPrice + deliveryFee;

  if (items.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <ShoppingBag className="w-24 h-24 text-gray-300 mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-2">Your cart is empty</h2>
          <p className="text-gray-500 mb-6">
            আপনার কার্ট খালি আছে। পণ্য যোগ করতে শপিং শুরু করুন।
          </p>
          <Link to="/">
            <Button className="bg-pink-600 hover:bg-pink-700">
              Continue Shopping
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold">Shopping Cart</h1>
            <p className="text-gray-500">শপিং কার্ট</p>
          </div>
          <Button
            variant="outline"
            onClick={clearCart}
            className="text-red-500 hover:text-red-700"
          >
            Clear Cart
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="font-bold text-lg mb-4">
                Items ({items.length})
              </h2>
              <div className="space-y-0">
                {items.map(item => (
                  <CartItem key={item.id} item={item} />
                ))}
              </div>
            </div>
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow p-6 sticky top-24">
              <h2 className="font-bold text-lg mb-4">Order Summary</h2>

              <div className="space-y-3 mb-4">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Subtotal</span>
                  <span className="font-medium">৳{totalPrice}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Delivery Fee</span>
                  <span className="font-medium">
                    {deliveryFee === 0 ? (
                      <span className="text-green-600">FREE</span>
                    ) : (
                      `৳${deliveryFee}`
                    )}
                  </span>
                </div>

                {deliveryFee > 0 && (
                  <p className="text-xs text-blue-600 bg-blue-50 p-2 rounded">
                    Add ৳{1500 - totalPrice} more for free delivery!
                  </p>
                )}

                <Separator />

                <div className="flex justify-between text-lg font-bold">
                  <span>Total</span>
                  <span className="text-pink-600">৳{finalTotal}</span>
                </div>
              </div>

              <Button className="w-full bg-pink-600 hover:bg-pink-700 h-12 mb-3">
                <Link to="/checkout" className="flex items-center justify-center w-full">
                  Proceed to Checkout
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Link>
              </Button>

              <Link to="/">
                <Button variant="outline" className="w-full">
                  Continue Shopping
                </Button>
              </Link>

              <div className="mt-6 space-y-2 text-xs text-gray-600">
                <p className="flex items-start">
                  <span className="text-green-600 mr-2">✓</span>
                  Secure payment processing
                </p>
                <p className="flex items-start">
                  <span className="text-green-600 mr-2">✓</span>
                  Free delivery in Dhaka over ৳1500
                </p>
                <p className="flex items-start">
                  <span className="text-green-600 mr-2">✓</span>
                  7-day return policy
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}