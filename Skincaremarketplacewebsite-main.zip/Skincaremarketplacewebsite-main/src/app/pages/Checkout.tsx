import { useState } from 'react';
import { useNavigate } from 'react-router';
import { ArrowLeft, CheckCircle2, CreditCard, Smartphone } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Separator } from '../components/ui/separator';

type PaymentMethod = 'bkash' | 'nagad' | 'card' | null;

export default function Checkout() {
  const navigate = useNavigate();
  const { items, getTotalPrice, clearCart } = useCart();
  const [selectedPayment, setSelectedPayment] = useState<PaymentMethod>(null);
  const [phoneNumber, setPhoneNumber] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [orderComplete, setOrderComplete] = useState(false);

  const totalPrice = getTotalPrice();
  const deliveryFee = totalPrice >= 1500 ? 0 : 60;
  const finalTotal = totalPrice + deliveryFee;

  // Customer info state
  const [customerInfo, setCustomerInfo] = useState({
    name: '',
    email: '',
    phone: '',
    address: '',
    city: 'Dhaka',
  });

  const handlePayment = async () => {
    if (!selectedPayment) return;
    
    setIsProcessing(true);
    // Simulate payment processing
    setTimeout(() => {
      setIsProcessing(false);
      setOrderComplete(true);
      clearCart();
    }, 2000);
  };

  if (items.length === 0 && !orderComplete) {
    navigate('/cart');
    return null;
  }

  if (orderComplete) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="bg-white rounded-lg shadow-lg p-8 max-w-md w-full text-center">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle2 className="w-12 h-12 text-green-600" />
          </div>
          <h2 className="text-2xl font-bold mb-2">Order Successful!</h2>
          <p className="text-gray-600 mb-1">অর্ডার সফল হয়েছে!</p>
          <p className="text-sm text-gray-500 mb-6">
            Your order has been placed successfully. We'll send you a confirmation shortly.
          </p>
          <div className="bg-gray-50 rounded-lg p-4 mb-6">
            <p className="text-sm text-gray-600">Order Total</p>
            <p className="text-3xl font-bold text-pink-600">৳{finalTotal}</p>
          </div>
          <Button
            onClick={() => navigate('/')}
            className="w-full bg-pink-600 hover:bg-pink-700"
          >
            Continue Shopping
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <Button
          variant="ghost"
          className="mb-6"
          onClick={() => navigate('/cart')}
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Cart
        </Button>

        <h1 className="text-3xl font-bold mb-2">Checkout</h1>
        <p className="text-gray-500 mb-8">চেকআউট</p>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Customer Information */}
            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-xl font-bold mb-4">Delivery Information</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">Full Name *</Label>
                  <Input
                    id="name"
                    value={customerInfo.name}
                    onChange={(e) => setCustomerInfo({ ...customerInfo, name: e.target.value })}
                    placeholder="Enter your name"
                  />
                </div>
                <div>
                  <Label htmlFor="phone">Phone Number *</Label>
                  <Input
                    id="phone"
                    value={customerInfo.phone}
                    onChange={(e) => setCustomerInfo({ ...customerInfo, phone: e.target.value })}
                    placeholder="01XXX-XXXXXX"
                  />
                </div>
                <div className="md:col-span-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={customerInfo.email}
                    onChange={(e) => setCustomerInfo({ ...customerInfo, email: e.target.value })}
                    placeholder="your@email.com"
                  />
                </div>
                <div className="md:col-span-2">
                  <Label htmlFor="address">Address *</Label>
                  <Input
                    id="address"
                    value={customerInfo.address}
                    onChange={(e) => setCustomerInfo({ ...customerInfo, address: e.target.value })}
                    placeholder="House, Road, Area"
                  />
                </div>
                <div>
                  <Label htmlFor="city">City *</Label>
                  <Input
                    id="city"
                    value={customerInfo.city}
                    onChange={(e) => setCustomerInfo({ ...customerInfo, city: e.target.value })}
                  />
                </div>
              </div>
            </div>

            {/* Payment Method */}
            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-xl font-bold mb-4">Payment Method</h2>
              <p className="text-sm text-gray-600 mb-4">পেমেন্ট মেথড নির্বাচন করুন</p>

              <div className="space-y-3">
                {/* bKash */}
                <button
                  onClick={() => setSelectedPayment('bkash')}
                  className={`w-full border-2 rounded-lg p-4 flex items-center justify-between transition-all ${
                    selectedPayment === 'bkash'
                      ? 'border-pink-500 bg-pink-50'
                      : 'border-gray-200 hover:border-pink-300'
                  }`}
                >
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-pink-500 rounded-lg flex items-center justify-center">
                      <span className="text-white font-bold text-xl">bৃ</span>
                    </div>
                    <div className="text-left">
                      <div className="font-bold text-lg">bKash</div>
                      <div className="text-sm text-gray-500">Pay with bKash mobile wallet</div>
                    </div>
                  </div>
                  {selectedPayment === 'bkash' && (
                    <div className="w-6 h-6 bg-pink-500 rounded-full flex items-center justify-center">
                      <CheckCircle2 className="w-4 h-4 text-white" />
                    </div>
                  )}
                </button>

                {/* Nagad */}
                <button
                  onClick={() => setSelectedPayment('nagad')}
                  className={`w-full border-2 rounded-lg p-4 flex items-center justify-between transition-all ${
                    selectedPayment === 'nagad'
                      ? 'border-orange-500 bg-orange-50'
                      : 'border-gray-200 hover:border-orange-300'
                  }`}
                >
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-orange-500 to-red-500 rounded-lg flex items-center justify-center">
                      <span className="text-white font-bold text-xl">৳</span>
                    </div>
                    <div className="text-left">
                      <div className="font-bold text-lg">Nagad</div>
                      <div className="text-sm text-gray-500">Pay with Nagad mobile wallet</div>
                    </div>
                  </div>
                  {selectedPayment === 'nagad' && (
                    <div className="w-6 h-6 bg-orange-500 rounded-full flex items-center justify-center">
                      <CheckCircle2 className="w-4 h-4 text-white" />
                    </div>
                  )}
                </button>

                {/* Card Payment */}
                <button
                  onClick={() => setSelectedPayment('card')}
                  className={`w-full border-2 rounded-lg p-4 flex items-center justify-between transition-all ${
                    selectedPayment === 'card'
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-200 hover:border-blue-300'
                  }`}
                >
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-blue-500 rounded-lg flex items-center justify-center">
                      <CreditCard className="w-6 h-6 text-white" />
                    </div>
                    <div className="text-left">
                      <div className="font-bold text-lg">Credit/Debit Card</div>
                      <div className="text-sm text-gray-500">Visa, Mastercard, Amex</div>
                    </div>
                  </div>
                  {selectedPayment === 'card' && (
                    <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center">
                      <CheckCircle2 className="w-4 h-4 text-white" />
                    </div>
                  )}
                </button>
              </div>

              {/* Payment Details Input */}
              {(selectedPayment === 'bkash' || selectedPayment === 'nagad') && (
                <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                  <Label htmlFor="paymentPhone">
                    {selectedPayment === 'bkash' ? 'bKash' : 'Nagad'} Account Number *
                  </Label>
                  <div className="flex items-center space-x-2 mt-2">
                    <Smartphone className="w-5 h-5 text-gray-400" />
                    <Input
                      id="paymentPhone"
                      value={phoneNumber}
                      onChange={(e) => setPhoneNumber(e.target.value)}
                      placeholder="01XXX-XXXXXX"
                      className="flex-1"
                    />
                  </div>
                  <p className="text-xs text-gray-500 mt-2">
                    Enter your {selectedPayment === 'bkash' ? 'bKash' : 'Nagad'} account number to complete the payment
                  </p>
                </div>
              )}

              {selectedPayment === 'card' && (
                <div className="mt-4 p-4 bg-gray-50 rounded-lg space-y-3">
                  <div>
                    <Label htmlFor="cardNumber">Card Number *</Label>
                    <Input
                      id="cardNumber"
                      placeholder="1234 5678 9012 3456"
                      className="mt-1"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <Label htmlFor="expiry">Expiry Date *</Label>
                      <Input
                        id="expiry"
                        placeholder="MM/YY"
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label htmlFor="cvv">CVV *</Label>
                      <Input
                        id="cvv"
                        placeholder="123"
                        type="password"
                        maxLength={3}
                        className="mt-1"
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow p-6 sticky top-24">
              <h2 className="text-xl font-bold mb-4">Order Summary</h2>

              {/* Items */}
              <div className="space-y-3 mb-4">
                {items.map(item => (
                  <div key={item.id} className="flex space-x-3">
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-16 h-16 object-cover rounded"
                    />
                    <div className="flex-1">
                      <p className="text-sm font-medium line-clamp-1">{item.name}</p>
                      <p className="text-xs text-gray-500">Qty: {item.quantity}</p>
                      <p className="text-sm font-medium text-pink-600">
                        ৳{item.price * item.quantity}
                      </p>
                    </div>
                  </div>
                ))}
              </div>

              <Separator className="my-4" />

              {/* Totals */}
              <div className="space-y-2 mb-4">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Subtotal</span>
                  <span className="font-medium">৳{totalPrice}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Delivery Fee</span>
                  <span className="font-medium">
                    {deliveryFee === 0 ? (
                      <span className="text-green-600">FREE</span>
                    ) : (
                      `৳${deliveryFee}`
                    )}
                  </span>
                </div>
                <Separator />
                <div className="flex justify-between text-lg font-bold">
                  <span>Total</span>
                  <span className="text-pink-600">৳{finalTotal}</span>
                </div>
              </div>

              <Button
                onClick={handlePayment}
                disabled={!selectedPayment || isProcessing || !customerInfo.name || !customerInfo.phone || !customerInfo.address}
                className="w-full bg-pink-600 hover:bg-pink-700 h-12"
              >
                {isProcessing ? (
                  'Processing...'
                ) : (
                  `Pay ৳${finalTotal}`
                )}
              </Button>

              <div className="mt-4 space-y-2 text-xs text-gray-600">
                <p className="flex items-start">
                  <span className="text-green-600 mr-2">✓</span>
                  Secure payment processing
                </p>
                <p className="flex items-start">
                  <span className="text-green-600 mr-2">✓</span>
                  Your payment is protected
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
