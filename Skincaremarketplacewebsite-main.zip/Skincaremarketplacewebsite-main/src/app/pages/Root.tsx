import { Outlet } from 'react-router';
import { Header } from '../components/Header';

export default function Root() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main>
        <Outlet />
      </main>
      <footer className="bg-gray-900 text-white mt-12">
        <div className="container mx-auto px-4 py-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="font-bold mb-4">Al Waqiah</h3>
              <p className="text-sm text-gray-400">
                Premium skincare products for Bangladesh.
              </p>
              <p className="text-sm text-gray-400 mt-2">الواقعة</p>
            </div>
            <div>
              <h4 className="font-medium mb-4">Quick Links</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>About Us</li>
                <li>Contact</li>
                <li>Shipping Info</li>
                <li>Returns</li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium mb-4">Categories</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>Cleansers</li>
                <li>Moisturizers</li>
                <li>Serums</li>
                <li>Sunscreen</li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium mb-4">Contact</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>Dhaka, Bangladesh</li>
                <li>support@skincarebd.com</li>
                <li>+880 1XXX-XXXXXX</li>
              </ul>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-gray-800 text-center text-sm text-gray-400">
            © 2026 Al Waqiah. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
}