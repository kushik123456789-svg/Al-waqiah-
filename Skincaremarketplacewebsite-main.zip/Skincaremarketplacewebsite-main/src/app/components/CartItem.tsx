import { Minus, Plus, Trash2 } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { Button } from './ui/button';

interface CartItemProps {
  item: {
    id: string;
    name: string;
    name_bn: string;
    price: number;
    image: string;
    brand: string;
    quantity: number;
  };
}

export function CartItem({ item }: CartItemProps) {
  const { updateQuantity, removeFromCart } = useCart();

  return (
    <div className="flex items-center space-x-4 py-4 border-b">
      {/* Image */}
      <img
        src={item.image}
        alt={item.name}
        className="w-20 h-20 object-cover rounded-lg"
      />

      {/* Details */}
      <div className="flex-1">
        <div className="text-xs text-gray-500">{item.brand}</div>
        <h3 className="font-medium text-gray-900">{item.name}</h3>
        <p className="text-xs text-gray-500">{item.name_bn}</p>
        <div className="mt-1 font-bold text-pink-600">৳{item.price}</div>
      </div>

      {/* Quantity Controls */}
      <div className="flex items-center space-x-2">
        <Button
          size="sm"
          variant="outline"
          className="w-8 h-8 p-0"
          onClick={() => updateQuantity(item.id, item.quantity - 1)}
        >
          <Minus className="w-4 h-4" />
        </Button>
        <span className="w-8 text-center font-medium">{item.quantity}</span>
        <Button
          size="sm"
          variant="outline"
          className="w-8 h-8 p-0"
          onClick={() => updateQuantity(item.id, item.quantity + 1)}
        >
          <Plus className="w-4 h-4" />
        </Button>
      </div>

      {/* Remove Button */}
      <Button
        size="sm"
        variant="ghost"
        className="text-red-500 hover:text-red-700 hover:bg-red-50"
        onClick={() => removeFromCart(item.id)}
      >
        <Trash2 className="w-5 h-5" />
      </Button>
    </div>
  );
}
