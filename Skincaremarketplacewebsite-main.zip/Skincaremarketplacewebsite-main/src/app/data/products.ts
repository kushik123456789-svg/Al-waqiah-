export interface Product {
  id: string;
  name: string;
  name_bn: string;
  description: string;
  price: number;
  originalPrice?: number;
  category: string;
  brand: string;
  image: string;
  inStock: boolean;
  rating: number;
  reviewCount: number;
  skinType: string[];
  benefits: string[];
}

export const categories = [
  { id: 'all', name: 'All Products', name_bn: 'সব পণ্য' },
  { id: 'cleansers', name: 'Cleansers', name_bn: 'ক্লিনজার' },
  { id: 'moisturizers', name: 'Moisturizers', name_bn: 'ময়েশ্চারাইজার' },
  { id: 'serums', name: 'Serums', name_bn: 'সিরাম' },
  { id: 'sunscreen', name: 'Sunscreen', name_bn: 'সানস্ক্রিন' },
  { id: 'masks', name: 'Face Masks', name_bn: 'ফেস মাস্ক' },
  { id: 'toners', name: 'Toners', name_bn: 'টোনার' },
  { id: 'eye-care', name: 'Eye Care', name_bn: 'আই কেয়ার' },
  { id: 'lip-care', name: 'Lip Care', name_bn: 'লিপ কেয়ার' },
];

export const products: Product[] = [
  {
    id: '1',
    name: 'Hydrating Daily Moisturizer',
    name_bn: 'হাইড্রেটিং ডেইলি ময়েশ্চারাইজার',
    description: 'Rich hydrating formula perfect for Bangladesh\'s humid climate. Locks in moisture without feeling heavy.',
    price: 1250,
    originalPrice: 1500,
    category: 'moisturizers',
    brand: 'GlowSkin',
    image: 'https://images.unsplash.com/photo-1597931752949-98c74b5b159f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxza2luY2FyZSUyMG1vaXN0dXJpemVyJTIwY3JlYW0lMjBib3R0bGV8ZW58MXx8fHwxNzc1MjI2MDIxfDA&ixlib=rb-4.1.0&q=80&w=1080',
    inStock: true,
    rating: 4.5,
    reviewCount: 234,
    skinType: ['dry', 'normal', 'combination'],
    benefits: ['Hydration', '24hr Moisture', 'Non-greasy']
  },
  {
    id: '2',
    name: 'Vitamin C Brightening Serum',
    name_bn: 'ভিটামিন সি ব্রাইটেনিং সিরাম',
    description: 'Powerful vitamin C formula to brighten and even skin tone. Reduces dark spots and hyperpigmentation.',
    price: 1800,
    originalPrice: 2200,
    category: 'serums',
    brand: 'PureGlow',
    image: 'https://images.unsplash.com/photo-1688413467024-c539918fdd7c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYWNlJTIwc2VydW0lMjBkcm9wcGVyJTIwYm90dGxlfGVufDF8fHx8MTc3NTIyNjAyMXww&ixlib=rb-4.1.0&q=80&w=1080',
    inStock: true,
    rating: 4.8,
    reviewCount: 456,
    skinType: ['all'],
    benefits: ['Brightening', 'Anti-aging', 'Even tone']
  },
  {
    id: '3',
    name: 'Gentle Foaming Cleanser',
    name_bn: 'জে���্টল ফোমিং ক্লিনজার',
    description: 'Mild foaming cleanser that removes dirt and pollution without stripping natural oils.',
    price: 850,
    category: 'cleansers',
    brand: 'ClearSkin',
    image: 'https://images.unsplash.com/photo-1556228578-f9707385e031?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjbGVhbnNlciUyMGZhY2UlMjB3YXNofGVufDF8fHx8MTc3NTIyNjAyMnww&ixlib=rb-4.1.0&q=80&w=1080',
    inStock: true,
    rating: 4.6,
    reviewCount: 189,
    skinType: ['all'],
    benefits: ['Deep cleansing', 'Gentle', 'pH balanced']
  },
  {
    id: '4',
    name: 'SPF 50+ Sunscreen',
    name_bn: 'এসপিএফ ৫০+ সানস্ক্রিন',
    description: 'Broad spectrum protection essential for Bangladesh sun. Light, non-greasy formula.',
    price: 950,
    originalPrice: 1100,
    category: 'sunscreen',
    brand: 'SunGuard',
    image: 'https://images.unsplash.com/photo-1594332322527-08753d4473c1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdW5zY3JlZW4lMjBib3R0bGUlMjBza2luY2FyZXxlbnwxfHx8fDE3NzUyMjYwMjJ8MA&ixlib=rb-4.1.0&q=80&w=1080',
    inStock: true,
    rating: 4.7,
    reviewCount: 567,
    skinType: ['all'],
    benefits: ['UVA/UVB protection', 'Water resistant', 'No white cast']
  },
  {
    id: '5',
    name: 'Hydrating Sheet Mask Pack',
    name_bn: 'হাইড্রেটিং শীট মাস্ক প্যাক',
    description: 'Set of 5 sheet masks infused with hyaluronic acid for instant hydration boost.',
    price: 650,
    category: 'masks',
    brand: 'MaskLab',
    image: 'https://images.unsplash.com/photo-1552046122-03184de85e08?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzaGVldCUyMGZhY2UlMjBtYXNrfGVufDF8fHx8MTc3NTIyNjAyMnww&ixlib=rb-4.1.0&q=80&w=1080',
    inStock: true,
    rating: 4.4,
    reviewCount: 312,
    skinType: ['all'],
    benefits: ['Instant hydration', 'Soothing', 'Cooling effect']
  },
  {
    id: '6',
    name: 'Balancing Facial Toner',
    name_bn: 'ব্যালান্সিং ফেসিয়াল টোনার',
    description: 'Alcohol-free toner that balances pH and prepares skin for better absorption.',
    price: 750,
    category: 'toners',
    brand: 'PureBalance',
    image: 'https://images.unsplash.com/photo-1697309006580-cda397ee09c2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0b25lciUyMHNwcmF5JTIwYm90dGxlfGVufDF8fHx8MTc3NTIxMzc4Nnww&ixlib=rb-4.1.0&q=80&w=1080',
    inStock: true,
    rating: 4.3,
    reviewCount: 145,
    skinType: ['oily', 'combination', 'normal'],
    benefits: ['Balancing', 'Refreshing', 'Pore minimizing']
  },
  {
    id: '7',
    name: 'Anti-Aging Eye Cream',
    name_bn: 'অ্যান্টি-এজিং আই ক্রিম',
    description: 'Targeted treatment for dark circles, puffiness, and fine lines around eyes.',
    price: 1400,
    originalPrice: 1650,
    category: 'eye-care',
    brand: 'YouthRevive',
    image: 'https://images.unsplash.com/photo-1731657979854-30bb7001cc8a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxleWUlMjBjcmVhbSUyMGphcnxlbnwxfHx8fDE3NzUyMjYwMjN8MA&ixlib=rb-4.1.0&q=80&w=1080',
    inStock: true,
    rating: 4.6,
    reviewCount: 278,
    skinType: ['all'],
    benefits: ['Reduces dark circles', 'Anti-aging', 'Firming']
  },
  {
    id: '8',
    name: 'Nourishing Lip Balm',
    name_bn: 'নারিশিং লিপ বাম',
    description: 'Intensive care lip balm with SPF 15. Heals and protects dry, chapped lips.',
    price: 350,
    category: 'lip-care',
    brand: 'LipCare',
    image: 'https://images.unsplash.com/photo-1773452451137-acc5fd1c0dfd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsaXAlMjBiYWxtJTIwc2tpbmNhcmV8ZW58MXx8fHwxNzc1MjI2MDIzfDA&ixlib=rb-4.1.0&q=80&w=1080',
    inStock: true,
    rating: 4.5,
    reviewCount: 423,
    skinType: ['all'],
    benefits: ['SPF 15', 'Long-lasting', 'Healing']
  },
];
